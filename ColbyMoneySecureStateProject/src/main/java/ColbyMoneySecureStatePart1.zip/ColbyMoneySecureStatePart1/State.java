package ColbyMoneySecureStatePart1;

public interface State {
    public void write();
    public void reject();
    public void accept();
}
